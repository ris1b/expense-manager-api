package com.expen.expensemanagerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseManagerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
